<?php
class migxFormtabField extends xPDOSimpleObject {}