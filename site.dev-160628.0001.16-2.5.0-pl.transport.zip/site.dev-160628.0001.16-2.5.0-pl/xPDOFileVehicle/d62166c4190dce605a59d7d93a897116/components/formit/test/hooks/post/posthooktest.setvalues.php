<?php
$hook->setValues(array(
  'name' => 'John Doe',
  'email' => 'john.doe@fake-emails.com',
));
return true;
