<?php

$_lang['ajaxform'] = 'AjaxForm';

$_lang['af_message_close_all'] = 'close all';
$_lang['af_submit'] = 'Submit';
$_lang['af_reset'] = 'Reset';

$_lang['af_label_name'] = 'Name';
$_lang['af_label_email'] = 'E-mail';
$_lang['af_label_message'] = 'Message';

$_lang['af_err_action_ns'] = 'Key of form not set (action).';
$_lang['af_err_action_nf'] = 'Could not find specified key of form (action).';
$_lang['af_err_chunk_ns'] = 'Chunk with form not set.';
$_lang['af_err_chunk_nf'] = 'Could not load specified chunk "[[+name]]" with form.';
$_lang['af_err_snippet_ns'] = 'Snippet for processing of form not set.';
$_lang['af_err_snippet_nf'] = 'Could not load specified snippet "[[+name]]" for processing of form.';
$_lang['af_err_has_errors'] = 'The form contains errors';
$_lang['af_success_submit'] = 'The form is successfully sent.';