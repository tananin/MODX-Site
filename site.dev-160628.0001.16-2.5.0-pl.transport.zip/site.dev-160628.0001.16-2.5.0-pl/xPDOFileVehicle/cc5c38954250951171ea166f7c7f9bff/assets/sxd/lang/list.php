<?php
$langs = array (
  'en' => 'English',
  'ru' => 'Русский',
  'uk' => 'Українська',
);
?>